boolean isNoTipo4(NoAN i){
   return (i.esq != null && i.dir != null && i.esq.cor == true && i.dir.cor == true);
}
