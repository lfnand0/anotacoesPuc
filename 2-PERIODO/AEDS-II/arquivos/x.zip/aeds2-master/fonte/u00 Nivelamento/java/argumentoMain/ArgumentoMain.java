class ArgumentoMain {
   public static void main (String[] args){
      System.out.println("Primeiro parametro: " + args[0]);
      System.out.println("Numero de parametros: " + args.length);
   }
}
