# U4 - Ordenação em memória principal

## Exemplo de como compilar o código

```
gcc -I. bolha_teste.c -o bolha_teste

```

## Exemplo de como executar o código

```
.\bolha_teste.exe 10
```
