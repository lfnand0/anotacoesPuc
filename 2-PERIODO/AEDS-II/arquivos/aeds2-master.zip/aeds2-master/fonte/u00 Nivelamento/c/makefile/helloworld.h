#ifndef _H_TESTE
#define _H_TESTE
 
void helloWorld(void);
 
#endif
