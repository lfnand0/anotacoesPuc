package com.jcg.hibernate.crud.view;
import java.awt.*;
import javax.swing.*;
import java.util.*;



public class CrudInterface {

    public CrudInterface() {
        JFrame janela;
    }
}
