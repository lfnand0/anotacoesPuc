/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc.modelo;

public class Aluno implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    private String dre;
    private String nome;
    private String tel;
    private String end;
    private String date;

    public Aluno(String dre, String nome, String telefone, String endereco, String data_Nasc) {
        super();
        this.dre = dre;
        this.nome = nome;
        this.tel = telefone;
        this.end = endereco;
        this.date = data_Nasc;
    }

    public String getDre() {
        return dre;
    }

    public void setDre(String dre) {
        this.dre = dre;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String telefone) {
        this.tel = telefone;
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String endereco) {
        this.end = endereco;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String data_Nasc) {
        this.date = data_Nasc;
    }
}
