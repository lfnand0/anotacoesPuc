# Trabalho Prático 1 de Algoritmos e Estruturas de Dados III
PUC Minas Praça da Liberdade - 3º Período 2022

Alunos: 
Gabriel Sebe Lucchesi Barbosa
Luiz Fernando Oliveira Maciel
