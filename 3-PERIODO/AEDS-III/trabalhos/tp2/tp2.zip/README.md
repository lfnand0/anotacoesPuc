# Trabalho Prático 2 de Algoritmos e Estruturas de Dados III
PUC Minas Praça da Liberdade - 3º Período 2022

Alunos: 
Gabriel Sebe Lucchesi Barbosa,
Luiz Fernando Oliveira Maciel

Repositório no Github: 
https://github.com/lfnand0/anotacoesPuc/tree/main/3-PERIODO/AEDS-III/trabalhos/tp2
