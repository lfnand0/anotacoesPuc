#include <stdio.h>

int main(){
    int n, i;
    printf("Digite um valor para n: ");
    scanf("%d", &n);
    for (i = 0; i < 10; i++) {
        printf("%d\n", n);
    }
}
