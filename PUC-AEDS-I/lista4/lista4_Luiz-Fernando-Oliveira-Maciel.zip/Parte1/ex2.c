#include <stdio.h>

int main()
{
    int n = 1;
    do
    {
        printf("%d\n", n);
        n++;
    } while (n <= 10);
}